<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
    <context>
        <name>TTSListMenu</name>
        <message>
            <location line="75" filename="../TTSListMenu.qml"/>
            <source>Configure Text to Speech</source>
            <translation>Text-zu-Sprache konfigurieren</translation>
        </message>
        <message>
            <location line="119" filename="../TTSListMenu.qml"/>
            <source>Text-To-Speech (TTS) is the process of converting strings of text into audio of spoken words</source>
            <translation>Text-To-Speech (TTS) ist der Prozess der Umwandlung von Textfolgen in Audio von gesprochenen Wörtern</translation>
        </message>
    </context>
</TS>

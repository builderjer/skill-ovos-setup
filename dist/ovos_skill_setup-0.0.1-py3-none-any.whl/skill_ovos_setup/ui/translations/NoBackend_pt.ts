<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
    <context>
        <name>NoBackend</name>
        <message>
            <location line="35" filename="../NoBackend.qml"/>
            <source>No Pairing Required</source>
            <translation>Não é necessário emparelhar</translation>
        </message>
        <message>
            <location line="38" filename="../NoBackend.qml"/>
            <source>Multiple configurable STT Options</source>
            <translation>Várias opções de STT configuráveis</translation>
        </message>
        <message>
            <location line="41" filename="../NoBackend.qml"/>
            <source>Multiple configurable TTS Options</source>
            <translation>Várias opções de TTS configuráveis</translation>
        </message>
        <message>
            <location line="44" filename="../NoBackend.qml"/>
            <source>No internet needed</source>
            <translation>Não precisa de internet</translation>
        </message>
        <message>
            <location line="83" filename="../NoBackend.qml"/>
            <source>No Backend</source>
            <translation>Sem back-end</translation>
        </message>
        <message>
            <location line="118" filename="../NoBackend.qml"/>
            <source>Allows your device to work offline</source>
            <translation>Permite que seu dispositivo funcione offline</translation>
        </message>
        <message>
            <location line="211" filename="../NoBackend.qml"/>
            <source>Backend Selection</source>
            <translation>Seleção de back-end</translation>
        </message>
        <message>
            <location line="254" filename="../NoBackend.qml"/>
            <source>Confirm</source>
            <translation>confirme</translation>
        </message>
    </context>
</TS>

<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
    <context>
        <name>Pairing</name>
        <message>
            <location line="58" filename="../Pairing.qml"/>
            <source>Pair this device at</source>
            <translation>Associez cet appareil à</translation>
        </message>
    </context>
</TS>

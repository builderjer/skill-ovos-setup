<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
    <context>
        <name>Pairing</name>
        <message>
            <location line="58" filename="../Pairing.qml"/>
            <source>Pair this device at</source>
            <translation>Koppeln Sie dieses Gerät unter</translation>
        </message>
    </context>
</TS>

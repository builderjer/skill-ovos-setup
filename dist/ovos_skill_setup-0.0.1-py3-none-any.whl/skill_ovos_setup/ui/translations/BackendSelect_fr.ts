<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
    <context>
        <name>BackendSelect</name>
        <message>
            <location line="66" filename="../BackendSelect.qml"/>
            <source>Select Your Backend</source>
            <translation>Sélectionnez votre back-end</translation>
        </message>
        <message>
            <location line="101" filename="../BackendSelect.qml"/>
            <source>A backend provides services used by OpenVoiceOS Core</source>
            <translation>Un back-end fournit des services utilisés par OpenVoiceOS Core</translation>
        </message>
        <message>
            <location line="119" filename="../BackendSelect.qml"/>
            <source>Backend</source>
            <translation>Back-end</translation>
        </message>
        <message>
            <location line="130" filename="../BackendSelect.qml"/>
            <source>Personal Backend</source>
            <translation>Back-end personnel</translation>
        </message>
        <message>
            <location line="141" filename="../BackendSelect.qml"/>
            <source>No Backend</source>
            <translation>Pas de back-end</translation>
        </message>
        <message>
            <location line="195" filename="../BackendSelect.qml"/>
            <source>Language Selection</source>
            <translation>Sélection de la langue</translation>
        </message>
    </context>
</TS>

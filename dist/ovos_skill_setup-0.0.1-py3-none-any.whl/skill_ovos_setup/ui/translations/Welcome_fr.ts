<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
    <context>
        <name>Welcome</name>
        <message>
            <location line="76" filename="../Welcome.qml"/>
            <source>Welcome to OpenVoice OS</source>
            <translation>Bienvenue dans le système d'exploitation OpenVoice</translation>
        </message>
        <message>
            <location line="120" filename="../Welcome.qml"/>
            <source>Let's get your device set up</source>
            <translation>Configurons votre appareil</translation>
        </message>
    </context>
</TS>

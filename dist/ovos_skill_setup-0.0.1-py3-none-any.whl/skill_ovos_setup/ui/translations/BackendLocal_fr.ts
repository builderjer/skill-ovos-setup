<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
    <context>
        <name>BackendLocal</name>
        <message>
            <location line="36" filename="../BackendLocal.qml"/>
            <source>Automatic Pairing</source>
            <translation>Couplage automatique</translation>
        </message>
        <message>
            <location line="39" filename="../BackendLocal.qml"/>
            <source>Needs to be hosted in a private network before hand</source>
            <translation>Doit être hébergé dans un réseau privé au préalable</translation>
        </message>
        <message>
            <location line="42" filename="../BackendLocal.qml"/>
            <source>Configure STT in backend</source>
            <translation>Configurer STT dans le back-end</translation>
        </message>
        <message>
            <location line="45" filename="../BackendLocal.qml"/>
            <source>Multiple Configurable TTS Options</source>
            <translation>Plusieurs options TTS configurables</translation>
        </message>
        <message>
            <location line="84" filename="../BackendLocal.qml"/>
            <source>Personal Backend</source>
            <translation>Back-end personnel</translation>
        </message>
        <message>
            <location line="120" filename="../BackendLocal.qml"/>
            <source>Manage all your devices using a personal backend</source>
            <translation>Gérez tous vos appareils à l'aide d'un back-end personnel</translation>
        </message>
        <message>
            <location line="213" filename="../BackendLocal.qml"/>
            <source>Backend Selection</source>
            <translation>Sélection principale</translation>
        </message>
        <message>
            <location line="256" filename="../BackendLocal.qml"/>
            <source>Confirm</source>
            <translation>Confirmer</translation>
        </message>
    </context>
</TS>

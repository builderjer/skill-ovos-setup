<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
    <context>
        <name>STTListMenu</name>
        <message>
            <location line="75" filename="../STTListMenu.qml"/>
            <source>Configure Speech to Text</source>
            <translation>Configura la sintesi vocale</translation>
        </message>
        <message>
            <location line="119" filename="../STTListMenu.qml"/>
            <source>Speech-To-Text (STT) is the process of converting audio of spoken words into strings of text</source>
            <translation>Speech-To-Text (STT) è il processo di conversione dell'audio delle parole pronunciate in stringhe di testo</translation>
        </message>
    </context>
</TS>

<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
    <context>
        <name>NoBackend</name>
        <message>
            <location line="35" filename="../NoBackend.qml"/>
            <source>No Pairing Required</source>
            <translation>Nessun abbinamento richiesto</translation>
        </message>
        <message>
            <location line="38" filename="../NoBackend.qml"/>
            <source>Multiple configurable STT Options</source>
            <translation>Opzioni STT multiple configurabili</translation>
        </message>
        <message>
            <location line="41" filename="../NoBackend.qml"/>
            <source>Multiple configurable TTS Options</source>
            <translation>Opzioni TTS multiple configurabili</translation>
        </message>
        <message>
            <location line="44" filename="../NoBackend.qml"/>
            <source>No internet needed</source>
            <translation>Non c'è bisogno di internet</translation>
        </message>
        <message>
            <location line="83" filename="../NoBackend.qml"/>
            <source>No Backend</source>
            <translation>Nessun backend</translation>
        </message>
        <message>
            <location line="118" filename="../NoBackend.qml"/>
            <source>Allows your device to work offline</source>
            <translation>Consente al tuo dispositivo di funzionare offline</translation>
        </message>
        <message>
            <location line="211" filename="../NoBackend.qml"/>
            <source>Backend Selection</source>
            <translation>Selezione backend</translation>
        </message>
        <message>
            <location line="254" filename="../NoBackend.qml"/>
            <source>Confirm</source>
            <translation>Confermare</translation>
        </message>
    </context>
</TS>

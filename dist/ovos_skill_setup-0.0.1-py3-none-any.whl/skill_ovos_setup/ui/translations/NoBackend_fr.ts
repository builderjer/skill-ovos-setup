<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
    <context>
        <name>NoBackend</name>
        <message>
            <location line="35" filename="../NoBackend.qml"/>
            <source>No Pairing Required</source>
            <translation>Aucun couplage requis</translation>
        </message>
        <message>
            <location line="38" filename="../NoBackend.qml"/>
            <source>Configurable STT Options: Google | Vosk</source>
            <translation>Options STT configurables : Google | </translation>
        </message>
        <message>
            <location line="41" filename="../NoBackend.qml"/>
            <source>Multiple Configurable TTS Options</source>
            <translation>Plusieurs options TTS configurables</translation>
        </message>
        <message>
            <location line="44" filename="../NoBackend.qml"/>
            <source>No internet needed</source>
            <translation>Pas besoin d'internet</translation>
        </message>
        <message>
            <location line="83" filename="../NoBackend.qml"/>
            <source>No Backend</source>
            <translation>Pas de back-end</translation>
        </message>
        <message>
            <location line="118" filename="../NoBackend.qml"/>
            <source>Allows your device to work offline</source>
            <translation>Permet à votre appareil de fonctionner hors ligne</translation>
        </message>
        <message>
            <location line="211" filename="../NoBackend.qml"/>
            <source>Backend Selection</source>
            <translation>Sélection principale</translation>
        </message>
        <message>
            <location line="254" filename="../NoBackend.qml"/>
            <source>Confirm</source>
            <translation>Confirmer</translation>
        </message>
    </context>
</TS>

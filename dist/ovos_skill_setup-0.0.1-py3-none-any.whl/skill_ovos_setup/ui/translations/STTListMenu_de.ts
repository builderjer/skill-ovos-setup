<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
    <context>
        <name>STTListMenu</name>
        <message>
            <location line="75" filename="../STTListMenu.qml"/>
            <source>Configure Speech to Text</source>
            <translation>Sprache zu Text konfigurieren</translation>
        </message>
        <message>
            <location line="119" filename="../STTListMenu.qml"/>
            <source>Speech-To-Text (STT) is the process of converting audio of spoken words into strings of text</source>
            <translation>Speech-To-Text (STT) ist der Prozess der Audioumwandlung gesprochener Wörter in Textfolgen</translation>
        </message>
    </context>
</TS>

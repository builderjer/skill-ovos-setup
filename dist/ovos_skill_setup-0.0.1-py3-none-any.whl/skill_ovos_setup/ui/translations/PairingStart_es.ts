<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
    <context>
        <name>PairingStart</name>
        <message>
            <location line="50" filename="../PairingStart.qml"/>
            <source>Fetching Pairing Code</source>
            <translation>Obteniendo código de emparejamiento</translation>
        </message>
        <message>
            <location line="75" filename="../PairingStart.qml"/>
            <source>I'm connected
and need to be
activated</source>
            <translation type="unfinished"/>
        </message>
    </context>
</TS>

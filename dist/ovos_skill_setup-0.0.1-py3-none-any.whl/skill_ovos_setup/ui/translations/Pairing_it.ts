<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
    <context>
        <name>Pairing</name>
        <message>
            <location line="58" filename="../Pairing.qml"/>
            <source>Pair this device at</source>
            <translation>Associa questo dispositivo a</translation>
        </message>
    </context>
</TS>

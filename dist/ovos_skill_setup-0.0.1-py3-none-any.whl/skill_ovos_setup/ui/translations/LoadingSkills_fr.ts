<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
    <context>
        <name>LoadingSkills</name>
        <message>
            <location line="30" filename="../LoadingSkills.qml"/>
            <source>Loading Skills</source>
            <translation>Chargement des compétences</translation>
        </message>
        <message>
            <location line="42" filename="../LoadingSkills.qml"/>
            <source>Almost Done</source>
            <translation>Presque fini</translation>
        </message>
    </context>
</TS>

<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
    <context>
        <name>BackendSelect</name>
        <message>
            <location line="66" filename="../BackendSelect.qml"/>
            <source>Select Your Backend</source>
            <translation>Seleccione su servidor</translation>
        </message>
        <message>
            <location line="101" filename="../BackendSelect.qml"/>
            <source>A backend provides services used by OpenVoiceOS Core</source>
            <translation>Un backend proporciona servicios utilizados por OpenVoiceOS Core</translation>
        </message>
        <message>
            <location line="119" filename="../BackendSelect.qml"/>
            <source>Backend</source>
            <translation>back-end</translation>
        </message>
        <message>
            <location line="130" filename="../BackendSelect.qml"/>
            <source>Personal Backend</source>
            <translation>Back-end personal</translation>
        </message>
        <message>
            <location line="141" filename="../BackendSelect.qml"/>
            <source>No Backend</source>
            <translation>Sin back-end</translation>
        </message>
        <message>
            <location line="195" filename="../BackendSelect.qml"/>
            <source>Language Selection</source>
            <translation>Selección de idioma</translation>
        </message>
    </context>
</TS>

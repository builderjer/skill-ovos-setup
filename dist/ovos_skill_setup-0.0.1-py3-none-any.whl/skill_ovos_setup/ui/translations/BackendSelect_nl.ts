<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="nl_NL">
    <context>
        <name>BackendSelect</name>
        <message>
            <location line="66" filename="../BackendSelect.qml"/>
            <source>Select Your Backend</source>
            <translation>Selecteer uw backend</translation>
        </message>
        <message>
            <location line="101" filename="../BackendSelect.qml"/>
            <source>A backend provides services used by OpenVoiceOS Core</source>
            <translation>Een backend biedt services die worden gebruikt door OpenVoiceOS Core</translation>
        </message>
        <message>
            <location line="119" filename="../BackendSelect.qml"/>
            <source>Backend</source>
            <translation>Backend</translation>
        </message>
        <message>
            <location line="130" filename="../BackendSelect.qml"/>
            <source>Personal Backend</source>
            <translation>Persoonlijke backend</translation>
        </message>
        <message>
            <location line="141" filename="../BackendSelect.qml"/>
            <source>No Backend</source>
            <translation>Geen backend</translation>
        </message>
        <message>
            <location line="195" filename="../BackendSelect.qml"/>
            <source>Language Selection</source>
            <translation>Taal selectie</translation>
        </message>
    </context>
</TS>

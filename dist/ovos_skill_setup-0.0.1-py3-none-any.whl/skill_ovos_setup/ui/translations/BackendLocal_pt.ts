<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
    <context>
        <name>BackendLocal</name>
        <message>
            <location line="36" filename="../BackendLocal.qml"/>
            <source>Automatic Pairing</source>
            <translation>Emparelhamento Automático</translation>
        </message>
        <message>
            <location line="39" filename="../BackendLocal.qml"/>
            <source>Needs to be hosted in a private network before hand</source>
            <translation>Precisa ser hospedado em uma rede privada antes da mão</translation>
        </message>
        <message>
            <location line="42" filename="../BackendLocal.qml"/>
            <source>Configure STT in backend</source>
            <translation>Configurar STT no back-end</translation>
        </message>
        <message>
            <location line="45" filename="../BackendLocal.qml"/>
            <source>Multiple configurable TTS Options</source>
            <translation>Várias opções de TTS configuráveis</translation>
        </message>
        <message>
            <location line="84" filename="../BackendLocal.qml"/>
            <source>Personal Backend</source>
            <translation>Back-end pessoal</translation>
        </message>
        <message>
            <location line="120" filename="../BackendLocal.qml"/>
            <source>Manage all your devices using a personal backend</source>
            <translation>Gerencie todos os seus dispositivos usando um back-end pessoal</translation>
        </message>
        <message>
            <location line="213" filename="../BackendLocal.qml"/>
            <source>Backend Selection</source>
            <translation>Seleção de back-end</translation>
        </message>
        <message>
            <location line="256" filename="../BackendLocal.qml"/>
            <source>Confirm</source>
            <translation>confirme</translation>
        </message>
    </context>
</TS>

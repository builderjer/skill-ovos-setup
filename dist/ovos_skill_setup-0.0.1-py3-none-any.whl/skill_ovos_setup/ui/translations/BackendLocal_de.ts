<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
    <context>
        <name>BackendLocal</name>
        <message>
            <location line="36" filename="../BackendLocal.qml"/>
            <source>Automatic Pairing</source>
            <translation>Automatische Kopplung</translation>
        </message>
        <message>
            <location line="39" filename="../BackendLocal.qml"/>
            <source>Needs to be hosted in a private network before hand</source>
            <translation>Muss in einem privaten Netzwerk gehostet werden</translation>
        </message>
        <message>
            <location line="42" filename="../BackendLocal.qml"/>
            <source>Configure STT in backend</source>
            <translation>Konfiguriere STT im Backend</translation>
        </message>
        <message>
            <location line="45" filename="../BackendLocal.qml"/>
            <source>Multiple configurable TTS Options</source>
            <translation>Mehrere konfigurierbare TTS-Optionen</translation>
        </message>
        <message>
            <location line="84" filename="../BackendLocal.qml"/>
            <source>Personal Backend</source>
            <translation>Persönliches Backend</translation>
        </message>
        <message>
            <location line="120" filename="../BackendLocal.qml"/>
            <source>Manage all your devices using a personal backend</source>
            <translation>Verwalte alle Geräte mit einem persönlichen Backend</translation>
        </message>
        <message>
            <location line="213" filename="../BackendLocal.qml"/>
            <source>Backend Selection</source>
            <translation>Backend-Auswahl</translation>
        </message>
        <message>
            <location line="256" filename="../BackendLocal.qml"/>
            <source>Confirm</source>
            <translation>Bestätigen</translation>
        </message>
    </context>
</TS>

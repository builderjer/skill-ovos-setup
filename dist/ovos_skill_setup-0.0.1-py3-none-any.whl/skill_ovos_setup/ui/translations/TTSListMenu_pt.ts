<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
    <context>
        <name>TTSListMenu</name>
        <message>
            <location line="75" filename="../TTSListMenu.qml"/>
            <source>Configure Text to Speech</source>
            <translation>Configurar texto para fala</translation>
        </message>
        <message>
            <location line="119" filename="../TTSListMenu.qml"/>
            <source>Text-To-Speech (TTS) is the process of converting strings of text into audio of spoken words</source>
            <translation>Text-To-Speech (TTS) é o processo de conversão de strings de texto em áudio de palavras faladas</translation>
        </message>
    </context>
</TS>

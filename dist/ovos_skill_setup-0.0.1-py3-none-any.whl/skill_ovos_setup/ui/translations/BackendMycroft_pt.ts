<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
    <context>
        <name>BackendMycroft</name>
        <message>
            <location line="35" filename="../BackendMycroft.qml"/>
            <source>Requires Pairing</source>
            <translation>Requer emparelhamento</translation>
        </message>
        <message>
            <location line="38" filename="../BackendMycroft.qml"/>
            <source>Uses Default Mycroft STT</source>
            <translation>Usa o padrão Mycroft STT</translation>
        </message>
        <message>
            <location line="41" filename="../BackendMycroft.qml"/>
            <source>Provides Web Skill Settings Interface</source>
            <translation>Fornece interface de configurações de habilidades da Web</translation>
        </message>
        <message>
            <location line="44" filename="../BackendMycroft.qml"/>
            <source>Provides Web Device Configuration Interface</source>
            <translation>Fornece interface de configuração de dispositivo da Web</translation>
        </message>
        <message>
            <location line="83" filename="../BackendMycroft.qml"/>
            <source>Backend</source>
            <translation>Processo interno</translation>
        </message>
        <message>
            <location line="118" filename="../BackendMycroft.qml"/>
            <source>The official backend service provided by</source>
            <translation>O serviço de back-end oficial fornecido por</translation>
        </message>
        <message>
            <location line="211" filename="../BackendMycroft.qml"/>
            <source>Backend Selection</source>
            <translation>Seleção de back-end</translation>
        </message>
        <message>
            <location line="255" filename="../BackendMycroft.qml"/>
            <source>Confirm</source>
            <translation>confirme</translation>
        </message>
    </context>
</TS>

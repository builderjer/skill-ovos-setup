<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
    <context>
        <name>LoadingSkills</name>
        <message>
            <location line="30" filename="../LoadingSkills.qml"/>
            <source>Loading Skills</source>
            <translation>Capacità di caricamento</translation>
        </message>
        <message>
            <location line="42" filename="../LoadingSkills.qml"/>
            <source>Almost Done</source>
            <translation>Quasi fatto</translation>
        </message>
    </context>
</TS>

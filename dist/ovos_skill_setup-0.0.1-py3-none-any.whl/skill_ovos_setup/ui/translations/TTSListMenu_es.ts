<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
    <context>
        <name>TTSListMenu</name>
        <message>
            <location line="75" filename="../TTSListMenu.qml"/>
            <source>Configure Text to Speech</source>
            <translation>Configurar texto a voz</translation>
        </message>
        <message>
            <location line="119" filename="../TTSListMenu.qml"/>
            <source>Text-To-Speech (TTS) is the process of converting strings of text into audio of spoken words</source>
            <translation>Text-To-Speech (TTS) es el proceso de convertir cadenas de texto en audio de palabras habladas</translation>
        </message>
    </context>
</TS>

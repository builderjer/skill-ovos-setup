<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
    <context>
        <name>BackendMycroft</name>
        <message>
            <location line="35" filename="../BackendMycroft.qml"/>
            <source>Requires Pairing</source>
            <translation>Nécessite un couplage</translation>
        </message>
        <message>
            <location line="38" filename="../BackendMycroft.qml"/>
            <source>Uses Default Mycroft STT</source>
            <translation>Utilise Mycroft STT par défaut</translation>
        </message>
        <message>
            <location line="41" filename="../BackendMycroft.qml"/>
            <source>Provides Web Skill Settings Interface</source>
            <translation>Fournit une interface de paramètres de compétences Web</translation>
        </message>
        <message>
            <location line="44" filename="../BackendMycroft.qml"/>
            <source>Provides Web Device Configuration Interface</source>
            <translation>Fournit une interface de configuration de périphérique Web</translation>
        </message>
        <message>
            <location line="83" filename="../BackendMycroft.qml"/>
            <source>Backend</source>
            <translation>Back-end</translation>
        </message>
        <message>
            <location line="118" filename="../BackendMycroft.qml"/>
            <source>The official backend service provided by</source>
            <translation>Le service back-end officiel fourni par</translation>
        </message>
        <message>
            <location line="211" filename="../BackendMycroft.qml"/>
            <source>Backend Selection</source>
            <translation>Sélection principale</translation>
        </message>
        <message>
            <location line="255" filename="../BackendMycroft.qml"/>
            <source>Confirm</source>
            <translation>Confirmer</translation>
        </message>
    </context>
</TS>

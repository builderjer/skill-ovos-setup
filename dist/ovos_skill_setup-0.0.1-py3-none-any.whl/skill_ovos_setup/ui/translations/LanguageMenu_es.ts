<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
    <context>
        <name>LanguageMenu</name>
        <message>
            <location line="66" filename="../LanguageMenu.qml"/>
            <source>Select Language</source>
            <translation>Seleccione el idioma</translation>
        </message>
        <message>
            <location line="194" filename="../LanguageMenu.qml"/>
            <source>Language selection affects your choice of avialable STT &amp; TTS engines</source>
            <translation>La selección de idioma afecta su elección de STT disponible</translation>
        </message>
    </context>
</TS>

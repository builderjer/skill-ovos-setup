<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
    <context>
        <name>LoadingScreen</name>
        <message>
            <location line="31" filename="../LoadingScreen.qml"/>
            <source>Starting Up</source>
            <translation>Cominciando</translation>
        </message>
        <message>
            <location line="43" filename="../LoadingScreen.qml"/>
            <source>Loading...</source>
            <translation>Caricamento in corso...</translation>
        </message>
    </context>
</TS>

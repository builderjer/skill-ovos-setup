<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="nl_NL">
    <context>
        <name>Pairing</name>
        <message>
            <location line="58" filename="../Pairing.qml"/>
            <source>Pair this device at</source>
            <translation>Koppel dit apparaat op</translation>
        </message>
    </context>
</TS>

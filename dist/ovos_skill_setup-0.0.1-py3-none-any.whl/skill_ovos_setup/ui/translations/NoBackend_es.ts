<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
    <context>
        <name>NoBackend</name>
        <message>
            <location line="35" filename="../NoBackend.qml"/>
            <source>No Pairing Required</source>
            <translation>No se requiere emparejamiento</translation>
        </message>
        <message>
            <location line="38" filename="../NoBackend.qml"/>
            <source>Multiple configurable STT Options</source>
            <translation>Múltiples opciones de STT configurables</translation>
        </message>
        <message>
            <location line="41" filename="../NoBackend.qml"/>
            <source>Multiple configurable TTS Options</source>
            <translation>Múltiples opciones de TTS configurables</translation>
        </message>
        <message>
            <location line="44" filename="../NoBackend.qml"/>
            <source>No internet needed</source>
            <translation>No se necesita internet</translation>
        </message>
        <message>
            <location line="83" filename="../NoBackend.qml"/>
            <source>No Backend</source>
            <translation>Sin back-end</translation>
        </message>
        <message>
            <location line="118" filename="../NoBackend.qml"/>
            <source>Allows your device to work offline</source>
            <translation>Permite que su dispositivo funcione sin conexión</translation>
        </message>
        <message>
            <location line="211" filename="../NoBackend.qml"/>
            <source>Backend Selection</source>
            <translation>Selección de back-end</translation>
        </message>
        <message>
            <location line="254" filename="../NoBackend.qml"/>
            <source>Confirm</source>
            <translation>Confirmar</translation>
        </message>
    </context>
</TS>

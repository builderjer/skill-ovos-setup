<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="nl_NL">
    <context>
        <name>LoadingSkills</name>
        <message>
            <location line="30" filename="../LoadingSkills.qml"/>
            <source>Loading Skills</source>
            <translation>Vaardigheden laden</translation>
        </message>
        <message>
            <location line="42" filename="../LoadingSkills.qml"/>
            <source>Almost Done</source>
            <translation>Bijna klaar</translation>
        </message>
    </context>
</TS>

<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="nl_NL">
    <context>
        <name>Welcome</name>
        <message>
            <location line="76" filename="../Welcome.qml"/>
            <source>Welcome to OpenVoice OS</source>
            <translation>Welkom bij OpenVoice OS</translation>
        </message>
        <message>
            <location line="120" filename="../Welcome.qml"/>
            <source>Let's get your device set up</source>
            <translation>Laten we uw apparaat instellen</translation>
        </message>
    </context>
</TS>

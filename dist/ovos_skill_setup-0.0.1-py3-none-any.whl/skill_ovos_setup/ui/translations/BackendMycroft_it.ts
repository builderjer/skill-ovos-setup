<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
    <context>
        <name>BackendMycroft</name>
        <message>
            <location line="35" filename="../BackendMycroft.qml"/>
            <source>Requires Pairing</source>
            <translation>Richiede l'abbinamento</translation>
        </message>
        <message>
            <location line="38" filename="../BackendMycroft.qml"/>
            <source>Uses Default Mycroft STT</source>
            <translation>Utilizza Mycroft STT predefinito</translation>
        </message>
        <message>
            <location line="41" filename="../BackendMycroft.qml"/>
            <source>Provides Web Skill Settings Interface</source>
            <translation>Fornisce l'interfaccia delle impostazioni delle abilità web</translation>
        </message>
        <message>
            <location line="44" filename="../BackendMycroft.qml"/>
            <source>Provides Web Device Configuration Interface</source>
            <translation>Fornisce l'interfaccia di configurazione del dispositivo Web</translation>
        </message>
        <message>
            <location line="83" filename="../BackendMycroft.qml"/>
            <source>Backend</source>
            <translation>Backend</translation>
        </message>
        <message>
            <location line="118" filename="../BackendMycroft.qml"/>
            <source>The official backend service provided by</source>
            <translation>Il servizio di backend ufficiale fornito da</translation>
        </message>
        <message>
            <location line="211" filename="../BackendMycroft.qml"/>
            <source>Backend Selection</source>
            <translation>Selezione backend</translation>
        </message>
        <message>
            <location line="255" filename="../BackendMycroft.qml"/>
            <source>Confirm</source>
            <translation>Confermare</translation>
        </message>
    </context>
</TS>

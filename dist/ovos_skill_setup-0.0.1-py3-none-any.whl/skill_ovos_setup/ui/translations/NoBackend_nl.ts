<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="nl_NL">
    <context>
        <name>NoBackend</name>
        <message>
            <location line="35" filename="../NoBackend.qml"/>
            <source>No Pairing Required</source>
            <translation>Koppelen niet nodig</translation>
        </message>
        <message>
            <location line="38" filename="../NoBackend.qml"/>
            <source>Multiple configurable STT Options</source>
            <translation>Meerdere configureerbare STT-opties</translation>
        </message>
        <message>
            <location line="41" filename="../NoBackend.qml"/>
            <source>Multiple configurable TTS Options</source>
            <translation>Meerdere configureerbare TTS-opties</translation>
        </message>
        <message>
            <location line="44" filename="../NoBackend.qml"/>
            <source>No internet needed</source>
            <translation>Geen internet nodig</translation>
        </message>
        <message>
            <location line="83" filename="../NoBackend.qml"/>
            <source>No Backend</source>
            <translation>Geen backend</translation>
        </message>
        <message>
            <location line="118" filename="../NoBackend.qml"/>
            <source>Allows your device to work offline</source>
            <translation>Hiermee kan uw apparaat offline werken</translation>
        </message>
        <message>
            <location line="211" filename="../NoBackend.qml"/>
            <source>Backend Selection</source>
            <translation>Backend-selectie</translation>
        </message>
        <message>
            <location line="254" filename="../NoBackend.qml"/>
            <source>Confirm</source>
            <translation>Bevestigen</translation>
        </message>
    </context>
</TS>

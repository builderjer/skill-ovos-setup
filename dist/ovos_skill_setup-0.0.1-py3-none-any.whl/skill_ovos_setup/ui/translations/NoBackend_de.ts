<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
    <context>
        <name>NoBackend</name>
        <message>
            <location line="35" filename="../NoBackend.qml"/>
            <source>No Pairing Required</source>
            <translation>Keine Kopplung erforderlich</translation>
        </message>
        <message>
            <location line="38" filename="../NoBackend.qml"/>
            <source>Multiple configurable STT Options</source>
            <translation>Mehrere konfigurierbare STT-Optionen</translation>
        </message>
        <message>
            <location line="41" filename="../NoBackend.qml"/>
            <source>Multiple Configurable TTS Options</source>
            <translation>Mehrere konfigurierbare TTS-Optionen</translation>
        </message>
        <message>
            <location line="44" filename="../NoBackend.qml"/>
            <source>No internet needed</source>
            <translation>Kein Internet erforderlich</translation>
        </message>
        <message>
            <location line="83" filename="../NoBackend.qml"/>
            <source>No Backend</source>
            <translation>Kein Backend</translation>
        </message>
        <message>
            <location line="118" filename="../NoBackend.qml"/>
            <source>Allows your device to work offline</source>
            <translation>Ermöglicht dem Gerät offline zu arbeiten</translation>
        </message>
        <message>
            <location line="211" filename="../NoBackend.qml"/>
            <source>Backend Selection</source>
            <translation>Backend-Auswahl</translation>
        </message>
        <message>
            <location line="254" filename="../NoBackend.qml"/>
            <source>Confirm</source>
            <translation>Bestätigen</translation>
        </message>
    </context>
</TS>

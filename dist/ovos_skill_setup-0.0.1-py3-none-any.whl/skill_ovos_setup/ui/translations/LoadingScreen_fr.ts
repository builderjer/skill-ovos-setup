<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
    <context>
        <name>LoadingScreen</name>
        <message>
            <location line="31" filename="../LoadingScreen.qml"/>
            <source>Starting Up</source>
            <translation>Démarrage</translation>
        </message>
        <message>
            <location line="43" filename="../LoadingScreen.qml"/>
            <source>Loading...</source>
            <translation>Chargement...</translation>
        </message>
    </context>
</TS>

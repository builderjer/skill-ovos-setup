<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="nl_NL">
    <context>
        <name>LanguageMenu</name>
        <message>
            <location line="66" filename="../LanguageMenu.qml"/>
            <source>Select Language</source>
            <translation>Selecteer taal</translation>
        </message>
        <message>
            <location line="194" filename="../LanguageMenu.qml"/>
            <source>Language selection affects your choice of avialable STT &amp; TTS engines</source>
            <translation>Taalkeuze is van invloed op uw keuze van beschikbare STT</translation>
        </message>
    </context>
</TS>

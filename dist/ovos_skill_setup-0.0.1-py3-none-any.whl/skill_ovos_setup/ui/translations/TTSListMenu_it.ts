<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
    <context>
        <name>TTSListMenu</name>
        <message>
            <location line="75" filename="../TTSListMenu.qml"/>
            <source>Configure Text to Speech</source>
            <translation>Configura Sintesi vocale</translation>
        </message>
        <message>
            <location line="119" filename="../TTSListMenu.qml"/>
            <source>Text-To-Speech (TTS) is the process of converting strings of text into audio of spoken words</source>
            <translation>Text-To-Speech (TTS) è il processo di conversione di stringhe di testo in audio di parole pronunciate</translation>
        </message>
    </context>
</TS>

<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
    <context>
        <name>LanguageMenu</name>
        <message>
            <location line="66" filename="../LanguageMenu.qml"/>
            <source>Select Language</source>
            <translation>Seleziona la lingua</translation>
        </message>
        <message>
            <location line="194" filename="../LanguageMenu.qml"/>
            <source>Language selection affects your choice of avialable STT &amp; TTS engines</source>
            <translation>La selezione della lingua influisce sulla scelta dell'STT disponibile</translation>
        </message>
    </context>
</TS>

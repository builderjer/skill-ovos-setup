<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
    <context>
        <name>LoadingScreen</name>
        <message>
            <location line="31" filename="../LoadingScreen.qml"/>
            <source>Starting Up</source>
            <translation>Starte</translation>
        </message>
        <message>
            <location line="43" filename="../LoadingScreen.qml"/>
            <source>Loading...</source>
            <translation>Wird geladen...</translation>
        </message>
    </context>
</TS>

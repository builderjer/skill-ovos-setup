<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
    <context>
        <name>PairingStart</name>
        <message>
            <location line="50" filename="../PairingStart.qml"/>
            <source>Fetching Pairing Code</source>
            <translation>Kopplungscode wird abgerufen</translation>
        </message>
        <message>
            <location line="75" filename="../PairingStart.qml"/>
            <source>I'm connected
and need to be
activated</source>
            <translation>Ich bin verbunden
und muss aktiviert
werden</translation>
        </message>
    </context>
</TS>

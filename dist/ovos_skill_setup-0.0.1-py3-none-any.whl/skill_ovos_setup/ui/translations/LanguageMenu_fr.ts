<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
    <context>
        <name>LanguageMenu</name>
        <message>
            <location line="66" filename="../LanguageMenu.qml"/>
            <source>Select Language</source>
            <translation>Choisir la langue</translation>
        </message>
        <message>
            <location line="194" filename="../LanguageMenu.qml"/>
            <source>Language selection affects your choice of avialable STT &amp; TTS engines</source>
            <translation>La sélection de la langue affecte votre choix de STT disponible</translation>
        </message>
    </context>
</TS>

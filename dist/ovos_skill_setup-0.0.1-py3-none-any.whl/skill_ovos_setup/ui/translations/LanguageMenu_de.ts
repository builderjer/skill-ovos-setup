<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
    <context>
        <name>LanguageMenu</name>
        <message>
            <location line="66" filename="../LanguageMenu.qml"/>
            <source>Select Language</source>
            <translation>Sprache auswählen</translation>
        </message>
        <message>
            <location line="194" filename="../LanguageMenu.qml"/>
            <source>Language selection affects your choice of avialable STT &amp; TTS engines</source>
            <translation>Die Sprachauswahl wirkt sich auf Ihre Auswahl an verfügbaren STT &amp; TTS aus</translation>
        </message>
    </context>
</TS>

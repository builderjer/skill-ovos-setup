<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
    <context>
        <name>LoadingScreen</name>
        <message>
            <location line="31" filename="../LoadingScreen.qml"/>
            <source>Starting Up</source>
            <translation>Começando</translation>
        </message>
        <message>
            <location line="43" filename="../LoadingScreen.qml"/>
            <source>Loading...</source>
            <translation>Carregando...</translation>
        </message>
    </context>
</TS>

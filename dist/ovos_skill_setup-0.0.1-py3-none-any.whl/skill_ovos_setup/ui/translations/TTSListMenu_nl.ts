<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="nl_NL">
    <context>
        <name>TTSListMenu</name>
        <message>
            <location line="75" filename="../TTSListMenu.qml"/>
            <source>Configure Text to Speech</source>
            <translation>Tekst naar spraak configureren</translation>
        </message>
        <message>
            <location line="119" filename="../TTSListMenu.qml"/>
            <source>Text-To-Speech (TTS) is the process of converting strings of text into audio of spoken words</source>
            <translation>Text-To-Speech (TTS) is het proces waarbij tekstreeksen worden omgezet in audio van gesproken woorden</translation>
        </message>
    </context>
</TS>
